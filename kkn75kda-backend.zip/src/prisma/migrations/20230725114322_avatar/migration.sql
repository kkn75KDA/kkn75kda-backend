-- AlterTable
ALTER TABLE "User" ALTER COLUMN "avatar" SET DEFAULT 'https://ik.imagekit.io/qlxmzsojb/KKN75/user.png?updatedAt=1690285305263';
