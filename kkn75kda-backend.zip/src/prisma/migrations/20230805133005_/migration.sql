-- DropIndex
DROP INDEX "KartuKeluarga_no_kk_key";
