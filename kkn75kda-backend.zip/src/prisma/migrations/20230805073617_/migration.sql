-- AlterTable
ALTER TABLE "Penduduk" ALTER COLUMN "tanggal_lahir" SET DATA TYPE TEXT;
