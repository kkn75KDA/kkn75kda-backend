-- AlterTable
ALTER TABLE "DataAsset" ALTER COLUMN "penghasilan" SET DATA TYPE TEXT;
